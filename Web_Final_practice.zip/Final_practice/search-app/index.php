<?php
// Include database connection
include 'db.php';

$searchResults = [];
if (isset($_GET['search'])) {
    $searchTerm = htmlspecialchars($_GET['search']);
    
    $stmt = $pdo->prepare("SELECT * FROM items WHERE name LIKE ?");
    $stmt->execute(["%$searchTerm%"]);
    $searchResults = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Simple Search with Database</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <div class="search-container">
    <input type="text" id="search-input" placeholder="Search..." onkeyup="searchContent()">
    <button id="search-button">Search</button>
  </div>

  <div id="content">
    <?php if (empty($searchResults)): ?>
      <div class="item">No results found.</div>
    <?php else: ?>
      <?php foreach ($searchResults as $item): ?>
        <div class="item"><?= htmlspecialchars($item['name']) ?></div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <script src="script.js"></script>
</body>
</html>
