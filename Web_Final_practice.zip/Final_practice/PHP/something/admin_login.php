<?php
session_start();
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE username=? AND password=? AND role='admin'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 1) {
        $admin = $res->fetch_assoc();
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['username'] = $admin['username'];
        header("Location: admin_dashboard.php");
    } else {
        echo "Invalid admin credentials!";
    }
}
?>

<form method="POST">
    <h2>Admin Login</h2>
    <input type="text" name="username" required placeholder="Admin Username"><br>
    <input type="password" name="password" required placeholder="Admin Password"><br>
    <input type="submit" value="Login">
</form>
