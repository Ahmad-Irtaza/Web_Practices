<?php
session_start();
session_destroy();
header("Location: user_login.php"); // or admin_login.php depending on who logged out
exit();
