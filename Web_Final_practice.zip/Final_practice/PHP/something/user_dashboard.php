<?php
session_start();
include "db.php";
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $book = $_POST['book'];
    $author = $_POST['author'];
    $uid = $_SESSION['user_id'];

    $sql = "INSERT INTO book_requests (user_id, book_name, author) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $uid, $book, $author);
    $stmt->execute();
    echo "Request submitted!";
}
?>

<h2>Welcome <?php echo $_SESSION['username']; ?> (User)</h2>
<a href="logout.php">Logout</a>

<form method="POST">
    <input type="text" name="book" placeholder="Book Name" required><br>
    <input type="text" name="author" placeholder="Author" required><br>
    <input type="submit" value="Request Book">
</form>
