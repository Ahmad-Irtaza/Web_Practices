CREATE DATABASE IF NOT EXISTS request_system;
USE request_system;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(100),
    role ENUM('user', 'admin')
);

-- Sample users
INSERT INTO users (username, password, role) VALUES
('user1', '1234', 'user'),
('admin1', 'admin', 'admin');

-- Book requests table
CREATE TABLE book_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    book_name VARCHAR(100),
    author VARCHAR(100),
    FOREIGN KEY (user_id) REFERENCES users(id)
);
