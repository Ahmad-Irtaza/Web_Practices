<?php
session_start();
include "db.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$sql = "SELECT book_requests.id, users.username, book_name, author FROM book_requests JOIN users ON book_requests.user_id = users.id";
$res = $conn->query($sql);
?>

<h2>Welcome <?php echo $_SESSION['username']; ?> (Admin)</h2>
<a href="logout.php">Logout</a>

<h3>All Book Requests</h3>
<table border="1" cellpadding="10">
    <tr>
        <th>User</th>
        <th>Book</th>
        <th>Author</th>
    </tr>
    <?php while ($row = $res->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['username']; ?></td>
            <td><?php echo $row['book_name']; ?></td>
            <td><?php echo $row['author']; ?></td>
        </tr>
    <?php endwhile; ?>
</table>
