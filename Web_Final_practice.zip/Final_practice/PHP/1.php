<!DOCTYPE html>
<html>
<head>
    <title>PHP Example</title>
</head>
<body>
    <h1>Welcome</h1>
    <p>
        <?php
        $name = "Ali";
        echo "Hello, $name!";
        ?>
    </p>
</body>
</html>
