<?php
// signup.php
session_start();

// Handle form submission
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username         = trim($_POST['username']);
    $password         = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } else {
        // Simple in-memory “database” in the session.
        if (! isset($_SESSION['users'])) {
            $_SESSION['users'] = [];
        }
        // Store a hashed password
        $_SESSION['users'][$username] = password_hash($password, PASSWORD_DEFAULT);

        // Redirect to login page
        header('Location: login.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Signup</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: black;
      color: white;
      text-align: center;
      padding: 50px;
      min-height: 100vh;
      margin: 0;
    }
    form {
      display: inline-block;
      text-align: left;
      background-color: #333;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 0 10px #888;
    }
    label {
      display: block;
      margin-top: 10px;
    }
    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 8px;
      margin-top: 5px;
      border: 1px solid #555;
      border-radius: 4px;
      box-sizing: border-box;
    }
    input[type="submit"] {
      margin-top: 20px;
      width: 100%;
      padding: 10px;
      border: none;
      border-radius: 4px;
      background-color: #555;
      color: white;
      cursor: pointer;
    }
    .error {
      color: #f66;
      margin-bottom: 10px;
    }
    .link {
      display: block;
      margin-top: 15px;
      color: #ccc;
      text-decoration: none;
    }
  </style>
</head>
<body>

  <h1>Signup Page</h1>

  <?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form action="signup.php" method="POST">
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" required>

    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required>

    <label for="confirm_password">Confirm Password:</label>
    <input type="password" id="confirm_password" name="confirm_password" required>

    <input type="submit" value="Sign Up">
  </form>

  <a href="login.php" class="link">Already have an account? Log in</a>

</body>
</html>
