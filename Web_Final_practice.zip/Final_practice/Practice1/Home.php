<?php
session_start();
if (! isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Home – Employee Details</title>
  <style>
  body {
  font-family: Arial, sans-serif;
  background-image: linear-gradient(to bottom, #f9f9f9, #fff);
  color: #333;
  margin: 0;
  padding: 20px;
}

.welcome {
  text-align: center;
  margin-bottom: 30px;
  font-size: 24px;
  font-weight: bold;
  color: #666;
}

table {
  width: 80%;
  margin: 0 auto 40px;
  border-collapse: collapse;
  border: 1px solid #ddd;
}

th, td {
  border: 1px solid #666;
  padding: 8px 12px;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  color: #333;
}

th {
  background-color: #efefef;
  font-size: 18px;
  font-weight: bold;
  color: #333;
}

tr:nth-child(even) {
  background-color: #f9f9f9;
}

/* Add some hover effect to the table rows */
tr:hover td {
  background-color: #f2f2f2;
}

  </style>
</head>
<body>

  <!-- 2. Personalized greeting -->
  <div class="welcome">
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
    <p>Here are the current employee details:</p>
  </div>

  <!-- 3. Your existing table -->
  <table>
    <thead>
      <tr>
        <th>Employee ID</th>
        <th>Name</th>
        <th>Department</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>001</td>
        <td>Irtaza Butt</td>
        <td>Engineering</td>
        <td>irtaza@example.com</td>
      </tr>
      <tr>
        <td>002</td>
        <td>Ahmed Irtaza</td>
        <td>Marketing</td>
        <td>ahmed@example.com</td>
      </tr>
      <tr>
        <td>003</td>
        <td>Fatima Ali</td>
        <td>Human Resources</td>
        <td>fatima.ali@example.com</td>
      </tr>
      <tr>
        <td>004</td>
        <td>Aais</td>
        <td>Finance</td>
        <td>ac@example.com</td>
      </tr>
    </tbody>
  </table>

  <!-- 4. Optional logout link -->
  <div style="text-align:center;">
    <a href="logout.php">Log out</a>
  </div>

</body>
</html>

<?php
include 'footer.php';
?>
