<?php
session_start();

// Sample users for demonstration
$users = [
    'admin' => ['password' => 'adminpass', 'type' => 'admin'],
    'user' => ['password' => 'userpass', 'type' => 'user']
];

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (isset($users[$username]) && $users[$username]['password'] === $password) {
        $_SESSION['username'] = $username;
        $_SESSION['user_type'] = $users[$username]['type'];
        header('Location: dashboard.php');
        exit();
    } else {
        $message = 'Invalid username or password';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <style>
    /* Internal CSS */
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
    }
    .login-form {
      width: 300px;
      margin: 100px auto;
      padding: 20px;
      background: #fff;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .login-form input {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    .login-form button {
      width: 100%;
      padding: 10px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 5px;
    }
    .login-form button:hover {
      background-color: #45a049;
    }
    .message {
      color: red;
      text-align: center;
    }
  </style>
</head>
<body>

  <div class="login-form">
    <h2>Login</h2>
    <?php if ($message): ?>
      <p class="message"><?= $message ?></p>
    <?php endif; ?>
    <form method="POST">
      <input type="text" name="username" placeholder="Username" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Login</button>
    </form>
  </div>

</body>
</html>
