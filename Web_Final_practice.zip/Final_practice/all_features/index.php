<?php
// Start the session to check if user is logged in
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Simple Project</title>
  <style>
    /* Internal CSS */
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }
    .navbar {
      background-color: #4CAF50;
      padding: 14px;
      color: white;
      text-align: center;
    }
    .navbar a {
      color: white;
      padding: 14px 20px;
      text-decoration: none;
      margin: 0 10px;
    }
    .navbar a:hover {
      background-color: #45a049;
    }
    .sidebar {
      width: 200px;
      height: 100vh;
      background-color: #333;
      padding-top: 20px;
      color: white;
      position: fixed;
    }
    .sidebar a {
      display: block;
      padding: 10px;
      color: white;
      text-decoration: none;
      margin: 5px 0;
    }
    .sidebar a:hover {
      background-color: #575757;
    }
    .content {
      margin-left: 220px;
      padding: 20px;
    }
    .search-bar input {
      padding: 10px;
      width: 200px;
      margin-right: 10px;
    }
    .search-results {
      margin-top: 20px;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <div class="navbar">
    <a href="index.php">Home</a>
    <a href="login.php">Login</a>
  </div>

  <!-- Sidebar -->
  <div class="sidebar">
    <a href="dashboard.php">Dashboard</a>
    <a href="logout.php">Logout</a>
  </div>

  <!-- Content -->
  <div class="content">
    <h1>Welcome to Simple Project</h1>

    <!-- Search Bar -->
    <div class="search-bar">
      <input type="text" id="search-input" placeholder="Search..." onkeyup="searchContent()">
    </div>

    <!-- Search Results -->
    <div id="search-results" class="search-results"></div>
  </div>

  <script>
    // Simple JavaScript for searching content on the page
    function searchContent() {
      const query = document.getElementById("search-input").value.toLowerCase();
      const resultsDiv = document.getElementById("search-results");

      const items = ['Apple', 'Banana', 'Cherry', 'Date', 'Grape', 'Lemon'];
      const filteredItems = items.filter(item => item.toLowerCase().includes(query));

      resultsDiv.innerHTML = filteredItems.length > 0 ? filteredItems.join('<br>') : 'No results found';
    }
  </script>
</body>
</html>
