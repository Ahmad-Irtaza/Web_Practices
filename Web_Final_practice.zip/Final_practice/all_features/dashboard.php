<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$userType = $_SESSION['user_type']; // 'admin' or 'user'
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <style>
    /* Internal CSS */
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }
    .navbar {
      background-color: #4CAF50;
      padding: 14px;
      color: white;
      text-align: center;
    }
    .sidebar {
      width: 200px;
      height: 100vh;
      background-color: #333;
      padding-top: 20px;
      color: white;
      position: fixed;
    }
    .sidebar a {
      display: block;
      padding: 10px;
      color: white;
      text-decoration: none;
      margin: 5px 0;
    }
    .sidebar a:hover {
      background-color: #575757;
    }
    .content {
      margin-left: 220px;
      padding: 20px;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <div class="navbar">
    <h1>Welcome to the Dashboard</h1>
  </div>

  <!-- Sidebar -->
  <div class="sidebar">
    <a href="index.php">Home</a>
    <a href="logout.php">Logout</a>
  </div>

  <!-- Content -->
  <div class="content">
    <?php if ($userType == 'admin'): ?>
      <h2>Admin Dashboard</h2>
      <p>As an Admin, you can manage the entire system.</p>
      <!-- Admin-specific content goes here -->
    <?php else: ?>
      <h2>User Dashboard</h2>
      <p>Welcome to your personal dashboard. You are a regular user.</p>
      <!-- User-specific content goes here -->
    <?php endif; ?>
  </div>

</body>
</html>
