// assets/js/auth.js
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('auth-form');
    form.addEventListener('submit', e => {
      const u = document.getElementById('username').value.trim();
      const p = document.getElementById('password').value.trim();
      if (!u || !p) {
        alert('Both fields are required.');
        e.preventDefault();
      }
    });
  });
  