<!-- includes/sidebar.php -->
<aside class="sidebar">
  <h3>Quick Links</h3>
  <ul>
    <li><a href="dashboard.php">Dashboard</a></li>
    <li><a href="about.php">Profile</a></li>
    <li><a href="contact.php">Settings</a></li>
  </ul>
</aside>
