<?php
require 'includes/db.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = trim($_POST['username']);
  $password = trim($_POST['password']);

  if ($username && $password) {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    try {
      $stmt->execute([$username, $hash]);
      $message = "Signup successful! <a href='login.php'>Login here</a>.";
    } catch (PDOException $e) {
      // duplicate entry error code 23000
      $message = $e->getCode() === '23000'
        ? 'Username already taken.'
        : 'Error: ' . $e->getMessage();
    }
  } else {
    $message = 'Please fill in both fields.';
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sign Up | MySite</title>
  <link rel="stylesheet" href="assets/css/auth.css">
</head>
<body>
  <?php include 'includes/navbar.php'; ?>

  <div class="auth-container">
    <h2>Sign Up</h2>
    <?php if ($message): ?>
      <p><?= $message ?></p>
    <?php endif; ?>
    <form id="auth-form" method="POST">
      <label for="username">Username</label>
      <input type="text" name="username" id="username">

      <label for="password">Password</label>
      <input type="password" name="password" id="password">

      <button type="submit">Sign Up</button>
    </form>
  </div>

  <script src="assets/js/auth.js"></script>
</body>
</html>
