<?php
// 1. Load MongoDB library
require 'vendor/autoload.php'; 
use MongoDB\Client;

// 2. Connect & select collection
$client     = new Client("mongodb://localhost:27017");
$collection = $client->exam_db->students;

// 3. Handle “Add student” form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add') {
    $name  = trim($_POST['name']  ?? '');
    $email = trim($_POST['email'] ?? '');
    $age   = (int)($_POST['age']  ?? 0);
    if ($name && $email && $age) {
        $collection->insertOne([
            'name'  => $name,
            'email' => $email,
            'age'   => $age
        ]);
    }
    header('Location: index.php');
    exit;
}

// 4. Handle “Delete student” link
if (isset($_GET['delete_id'])) {
    $collection->deleteOne([
      '_id' => new MongoDB\BSON\ObjectId($_GET['delete_id'])
    ]);
    header('Location: index.php');
    exit;
}

// 5. Fetch all students
$students = $collection->find()->toArray();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Student Management</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header><h1>Student Management</h1></header>
  <main>
    <!-- Add Student Form -->
    <form method="POST" id="student-form">
      <input type="hidden" name="action" value="add">
      <input name="name"  placeholder="Name"  required>
      <input name="email" type="email" placeholder="Email" required>
      <input name="age"   type="number" placeholder="Age"   min="1" required>
      <button type="submit">Add</button>
    </form>

    <!-- Live Search -->
    <input id="search" placeholder="Search by name…">

    <!-- Student Table -->
    <table id="student-table">
      <thead>
        <tr><th>Name</th><th>Email</th><th>Age</th><th>Action</th></tr>
      </thead>
      <tbody>
        <?php foreach ($students as $s): ?>
        <tr>
          <td><?= htmlspecialchars($s['name'])   ?></td>
          <td><?= htmlspecialchars($s['email'])  ?></td>
          <td><?= htmlspecialchars($s['age'])    ?></td>
          <td>
            <a href="?delete_id=<?= $s['_id'] ?>"`
               onclick="return confirm('Delete this student?')">
               Delete
            </a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </main>
  <script src="script.js"></script>
</body>
</html>
