<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Time-Based Greeting</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Time-Based Greeting</h1>

    <div id="greeting">
        <?php
        date_default_timezone_set('Asia/Karachi'); // Set the timezone for Pakistan

        $hour = date('H'); // Get the current hour in 24-hour format (00-23)

        if ($hour >= 5 && $hour < 12) {
            $greeting = "Good morning!";
            $message = "Enjoy the start of your day.";
            $bgColor = "#f0f8ff"; // AliceBlue
            $textColor = "#191970"; // MidnightBlue
        } elseif ($hour >= 12 && $hour < 17) {
            $greeting = "Good afternoon!";
            $message = "Hope you're having a productive day.";
            $bgColor = "#fffacd"; // LemonChiffon
            $textColor = "#8b4513"; // SaddleBrown
        } else {
            $greeting = "Good evening!";
            $message = "Relax and unwind for the night.";
            $bgColor = "#4682b4"; // SteelBlue
            $textColor = "#fff"; // White
        }

        echo "<h2 style='color: " . $textColor . ";'>" . $greeting . "</h2>";
        echo "<p style='color: " . $textColor . ";'>" . $message . "</p>";
        ?>
    </div>

    <style>
        body {
            font-family: sans-serif;
            margin: 20px;
            background-color: <?php echo $bgColor; ?>;
            color: <?php echo $textColor; ?>;
        }

        h1 {
            color: #007bff;
            text-align: center;
            margin-bottom: 20px;
        }

        #greeting {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
    </style>
</body>
</html>