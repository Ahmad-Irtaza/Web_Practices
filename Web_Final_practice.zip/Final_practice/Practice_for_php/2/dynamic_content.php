<?php
$currentTime = date("h:i:s A");
$greeting = "Hello there!";
$dynamicText = "$greeting The current time is: $currentTime";
?>


