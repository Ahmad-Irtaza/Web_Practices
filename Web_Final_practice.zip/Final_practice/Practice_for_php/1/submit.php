<?php 

if($_SERVER['REQUEST_METHOD']=="POST")
{$name=$_POST['name'];
$email=$_POST['email'];
$message=$_POST['messgage'];


echo "<h1>Thank you, $name!</h1>";
echo "Email: $email <br>";
echo "Message: $message <br>";
// Validate the email address
}
else{
    echo "<h1>Invalid request method</h1>";
    echo "Please submit the form.";
    exit();
}

?>