<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Counter</title>
    <!-- <link rel="stylesheet" href="style.css"> -->
<style>
    body {
    font-family: sans-serif;
    margin: 20px;
    background-color: #f4f4f4;
    color: #333;
}

h1 {
    color: #007bff;
    text-align: center;
    margin-bottom: 20px;
}

p#dynamicContent {
    background-color: #e9ecef;
    padding: 15px;
    border-radius: 5px;
    font-size: 1.1em;
}
</style>

</head>
<body>
    <h1>Simple Counter</h1>

    <div id="counter">
        
        <?php
        // Define a file to store the counter value
        $counterFile = 'counter.txt';

        // Initialize the counter if the file doesn't exist or is empty
        if (!file_exists($counterFile) || filesize($counterFile) == 0) {
            file_put_contents($counterFile, 0);
            $count = 0;
        } else {
            
            // Read the current count from the file
            $count = (int) file_get_contents($counterFile);

            // Increment the counter
            $count++;

            // Write the updated count back to the file
            file_put_contents($counterFile, $count);
        }

        // Display the current count
        echo "<p>Page has been viewed <strong>" . $count . "</strong> times.</p>";
        ?>
    </div>
</body>
</html>