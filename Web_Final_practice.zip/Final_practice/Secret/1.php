<?php
// =========================================
// ✅ SECTION 1: Database Connection
// =========================================
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web_exam";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully"; 
}
catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

// =========================================
// ✅ SECTION 2: Simple Form Handling (POST)
// =========================================
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    echo "Username: $username <br>";
    echo "Password: $password <br>";
}

// Simple HTML Form for demonstration
echo '<form method="POST" action="">
        <input type="text" name="username" placeholder="Username">
        <input type="password" name="password" placeholder="Password">
        <input type="submit" value="Submit">
      </form>';

// =========================================
// ✅ SECTION 3: User Login (Session Handling)
// =========================================
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Dummy login for demonstration (normally you'd check the database here)
    if ($username == "admin" && $password == "password123") {
        $_SESSION['user'] = $username;
        echo "Login successful! Welcome, $username.";
    } else {
        echo "Invalid credentials.";
    }
}

// Simple login form
echo '<form method="POST" action="">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="submit" name="login" value="Login">
      </form>';

// =========================================
// ✅ SECTION 4: User Logout (Session Handling)
// =========================================
if (isset($_POST['logout'])) {
    session_destroy();  // Destroy the session
    echo "You have logged out.";
}

// Logout button
echo '<form method="POST" action="">
        <input type="submit" name="logout" value="Logout">
      </form>';

// =========================================
// ✅ SECTION 5: CRUD Operations (Create, Read, Update, Delete)
// =========================================
// Create
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    
    $sql = "INSERT INTO users (name, email) VALUES ('$name', '$email')";
    $conn->exec($sql);
    echo "New record created successfully.";
}

// Read
$stmt = $conn->prepare("SELECT id, name, email FROM users");
$stmt->execute();
$users = $stmt->fetchAll();

echo "<h3>Users List:</h3>";
foreach ($users as $user) {
    echo "ID: " . $user['id'] . " - Name: " . $user['name'] . " - Email: " . $user['email'] . "<br>";
}

// Update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $id = $_POST['id'];
    $new_name = $_POST['new_name'];

    $sql = "UPDATE users SET name = '$new_name' WHERE id = $id";
    $conn->exec($sql);
    echo "Record updated successfully.";
}

// Delete
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    $id = $_POST['id'];

    $sql = "DELETE FROM users WHERE id = $id";
    $conn->exec($sql);
    echo "Record deleted successfully.";
}

// CRUD Forms
echo '<form method="POST" action="">
        <input type="text" name="name" placeholder="Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="submit" name="create" value="Create">
      </form>';

echo '<form method="POST" action="">
        <input type="number" name="id" placeholder="User ID to Update/Delete" required>
        <input type="text" name="new_name" placeholder="New Name">
        <input type="submit" name="update" value="Update">
        <input type="submit" name="delete" value="Delete">
      </form>';

// =========================================
// ✅ SECTION 6: File Upload Handling
// =========================================
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['fileToUpload'])) {
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);

    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

// File Upload Form
echo '<form action="" method="POST" enctype="multipart/form-data">
        Select file to upload:
        <input type="file" name="fileToUpload" id="fileToUpload">
        <input type="submit" value="Upload File" name="submit">
      </form>';

// =========================================
// ✅ SECTION 7: Prepared Statements (SQL Injection Prevention)
// =========================================
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['safe_query'])) {
    $username = $_POST['username_safe'];
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE name = :name");
    $stmt->bindParam(':name', $username);
    $stmt->execute();
    
    $user = $stmt->fetch();
    if ($user) {
        echo "User found: " . $user['name'] . " - " . $user['email'];
    } else {
        echo "No user found.";
    }
}

// Safe Query Form
echo '<form method="POST" action="">
        <input type="text" name="username_safe" placeholder="Enter name" required>
        <input type="submit" name="safe_query" value="Search User">
      </form>';
?>

