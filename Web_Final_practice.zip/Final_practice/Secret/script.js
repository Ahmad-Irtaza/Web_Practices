// =========================================
// ✅ SECTION 1: Basic Output & Variables
// =========================================
console.log("Hello, Web Engineering!");
let name = "Hassan";
const age = 21;
var country = "Pakistan";

// =========================================
// ✅ SECTION 2: Functions (Named + Arrow)
// =========================================
function greet(user) {
  return "Welcome, " + user + "!";
}

const add = (a, b) => a + b;

console.log(greet(name));           // Welcome, Hassan
console.log(add(5, 10));            // 15

// =========================================
// ✅ SECTION 3: Conditional Statements
// =========================================
let marks = 85;
if (marks >= 80) {
  console.log("Grade: A");
} else {
  console.log("Grade: B or below");
}

// =========================================
// ✅ SECTION 4: Loops (for, while, forEach)
// =========================================
for (let i = 1; i <= 3; i++) {
  console.log("Loop Count: " + i);
}

let n = 0;
while (n < 2) {
  console.log("While Loop: " + n);
  n++;
}

[10, 20, 30].forEach(num => console.log("Number: " + num));

// =========================================
// ✅ SECTION 5: Arrays & Objects
// =========================================
let fruits = ["Apple", "Banana", "Mango"];
let student = { name: "Ali", roll: 101 };

console.log(fruits[1]);         // Banana
console.log(student.name);      // Ali

// =========================================
// ✅ SECTION 6: DOM Manipulation
// =========================================
// Assumes: <div id="demo"></div>

document.getElementById("demo").innerText = "Updated with JS!";
document.body.style.backgroundColor = "#f0f0f0";

// =========================================
// ✅ SECTION 7: Events
// =========================================
// Assumes: <button id="clickMe">Click</button>

document.getElementById("clickMe").addEventListener("click", () => {
  alert("Button Clicked!");
});

// =========================================
// ✅ SECTION 8: Form Validation
// =========================================
// Assumes: <form id="myForm"><input id="myInput"></form>

document.getElementById("myForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const input = document.getElementById("myInput").value;
  if (input === "") {
    alert("Input cannot be empty!");
  } else {
    alert("Submitted: " + input);
  }
});

// =========================================
// ✅ SECTION 9: Add & Remove DOM Elements
// =========================================
// Assumes: <ul id="list"></ul> and <button id="addItem">Add Item</button>

document.getElementById("addItem").addEventListener("click", () => {
  const li = document.createElement("li");
  li.innerText = "New List Item";
  document.getElementById("list").appendChild(li);
});

document.getElementById("list").addEventListener("click", (e) => {
  if (e.target.tagName === "LI") {
    e.target.remove();  // Remove clicked <li>
  }
});

// =========================================
// ✅ SECTION 10: Changing Elements Dynamically
// =========================================
// Assumes: <div id="changeMe">Change Me!</div> and <button id="changeBtn">

document.getElementById("changeBtn").addEventListener("click", () => {
  const div = document.getElementById("changeMe");
  div.innerHTML = "<b>Changed!</b>";
  div.style.color = "purple";
  div.classList.toggle("highlight");
});

// =========================================
// ✅ SECTION 11: Event Propagation
// =========================================
// Assumes:
// <div id="outer"><div id="inner">Click Me</div></div>

document.getElementById("outer").addEventListener("click", () => {
  console.log("Outer Div Clicked");
}, true); // Capturing Phase

document.getElementById("inner").addEventListener("click", (e) => {
  console.log("Inner Div Clicked");
  e.stopPropagation(); // Stops bubbling
});
