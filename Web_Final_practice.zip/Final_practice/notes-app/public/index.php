<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Simple Notes App</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>My Notes</h1>
  </header>
  <main>
    <section id="new-note">
      <form id="noteForm">
        <input type="text" id="noteText" placeholder="Write a new note…" required>
        <button type="submit">Add Note</button>
      </form>
    </section>
    <section id="notes-list">
      <!-- notes will be injected here -->
    </section>
  </main>
  <script src="script.js"></script>
</body>
</html>
