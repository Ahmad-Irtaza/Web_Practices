const form = document.getElementById('noteForm');
const list = document.getElementById('notes-list');

// fetch and render all notes on load
async function loadNotes() {
  const res = await fetch('../api/get_notes.php');
  const notes = await res.json();
  list.innerHTML = '';
  notes.forEach(n => {
    const div = document.createElement('div');
    div.className = 'note';
    div.innerHTML = `
      <span>${n.text}</span>
      <button data-id="${n._id.$oid}">×</button>
    `;
    list.appendChild(div);
  });
}

// handle note deletion
list.addEventListener('click', async e => {
  if (!e.target.matches('button')) return;
  const id = e.target.dataset.id;
  await fetch(`../api/delete_note.php?id=${id}`);
  loadNotes();
});

// handle new note submission
form.addEventListener('submit', async e => {
  e.preventDefault();
  const text = document.getElementById('noteText').value.trim();
  if (!text) return;                // logic: prevent empty
  await fetch('../api/add_note.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ text })
  });
  form.reset();
  loadNotes();
});

// initial load
loadNotes();
