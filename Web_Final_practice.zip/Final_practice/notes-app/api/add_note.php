<?php
header('Content-Type: application/json');
require '../vendor/autoload.php';

$input = json_decode(file_get_contents('php://input'), true);
$text  = trim($input['text'] ?? '');

if ($text === '') {
  http_response_code(400);
  echo json_encode(['error'=>'Empty note']);
  exit;
}

$client = new MongoDB\Client("mongodb://localhost:27017");
$collection = $client->notes_app->notes;
$result = $collection->insertOne(['text'=>$text, 'created_at'=>new MongoDB\BSON\UTCDateTime()]);

echo json_encode(['insertedId'=>(string)$result->getInsertedId()]);
