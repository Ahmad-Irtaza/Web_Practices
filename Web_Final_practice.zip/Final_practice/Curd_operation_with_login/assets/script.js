// simple form validation
function validateSignup() {
    const u = document.getElementById('username').value.trim();
    const e = document.getElementById('email').value.trim();
    const p = document.getElementById('password').value;
    const msg = document.getElementById('error-msg');
    if (!u || !e || !p) {
      msg.textContent = 'All fields are required.';
      return false;
    }
    if (p.length < 6) {
      msg.textContent = 'Password must be at least 6 characters.';
      return false;
    }
    return true;
  }
  