<?php
require 'config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$userId = $_SESSION['user_id'];

// Handle Delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $pdo->prepare("DELETE FROM items WHERE id = ? AND user_id = ?")
        ->execute([$id, $userId]);
    header('Location: dashboard.php');
    exit;
}

// Handle Edit (prefill form)
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $pdo->prepare("SELECT * FROM items WHERE id = ? AND user_id = ?");
    $stmt->execute([$id, $userId]);
    $it = $stmt->fetch();
    if ($it) {
        // render same form but with values (for brevity you could redirect back to dashboard with JS to prefill)
        $_SESSION['edit_item'] = $it;
    }
    header('Location: dashboard.php');
    exit;
}

// Handle Create / Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['action'];
    $title = trim($_POST['title']);
    $desc  = trim($_POST['description']);
    if ($act === 'create') {
        $pdo->prepare("INSERT INTO items (user_id,title,description) VALUES (?,?,?)")
            ->execute([$userId, $title, $desc]);
    } elseif ($act === 'update' && !empty($_POST['id'])) {
        $id = intval($_POST['id']);
        $pdo->prepare("UPDATE items SET title = ?, description = ? WHERE id = ? AND user_id = ?")
            ->execute([$title, $desc, $id, $userId]);
        unset($_SESSION['edit_item']);
    }
    header('Location: dashboard.php');
    exit;
}
