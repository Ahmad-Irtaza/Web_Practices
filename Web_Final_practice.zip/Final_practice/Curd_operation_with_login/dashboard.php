<?php
require 'config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$msg = '';
// fetch all items for this user
$stmt = $pdo->prepare("SELECT * FROM items WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$userId]);
$items = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Your Dashboard</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <div class="container">
    <h2>My Items <a href="logout.php" style="float:right;color:#dc3545;">Logout</a></h2>

    <!-- Add / Edit Form -->
    <form method="POST" action="process_item.php">
      <input type="hidden" name="id" value="">
      <input type="text" name="title" placeholder="Title" required>
      <textarea name="description" placeholder="Description"></textarea>
      <button type="submit" name="action" value="create">Add Item</button>
    </form>

    <!-- List of Items -->
    <?php if (count($items)): ?>
      <table class="table">
        <tr><th>Title</th><th>Description</th><th>Actions</th></tr>
        <?php foreach ($items as $it): ?>
          <tr>
            <td><?=htmlspecialchars($it['title'])?></td>
            <td><?=nl2br(htmlspecialchars($it['description']))?></td>
            <td class="actions">
              <a href="process_item.php?edit=<?= $it['id'] ?>">Edit</a>
              <a href="process_item.php?delete=<?= $it['id'] ?>" onclick="return confirm('Delete?')">Delete</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </table>
    <?php else: ?>
      <p>No items yet.</p>
    <?php endif; ?>

  </div>
</body>
</html>
