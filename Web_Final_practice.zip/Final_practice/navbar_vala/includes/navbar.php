<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>


    <style>
        /* Simple Sidebar Styling */
.sidebar {
  width: 200px;
  background: #f8f9fa;
  padding: 20px;
  border-right: 1px solid #ddd;
}

.sidebar h3 {
  font-size: 16px;
  color: #333;
  margin-bottom: 15px;
}

.sidebar ul {
  list-style: none;
  padding: 0;
}

.sidebar ul li {
  margin-bottom: 10px;
}

.sidebar ul li a {
  display: block;
  text-decoration: none;
  color: #555;
  padding: 8px;
  border-radius: 4px;
}

.sidebar ul li a:hover {
  background: #e9ecef;
  color: #333;
}

    </style>
</head>
<body>
    


<nav class="navbar">
  <div class="logo"><a href="index.php">MySite</a></div>
  <ul class="nav-links">
    <li><a href="index.php">Home</a></li>
    <li><a href="about.php">About</a></li>
    <li><a href="contact.php">Contact</a></li>
  </ul>
  <button class="nav-toggle" id="nav-toggle">☰</button>
</nav>








</body>
</html>
