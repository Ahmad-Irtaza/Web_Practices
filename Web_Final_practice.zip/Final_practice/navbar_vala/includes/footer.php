<!-- includes/footer.php -->
<footer class="footer">
  <p>&copy; <?= date('Y') ?> MySite. All rights reserved.</p>
</footer>
