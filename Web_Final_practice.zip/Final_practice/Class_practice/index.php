<style>
    div{
        display: flex;
        justify-content: center;
        margin-top: 3%;
    }
    form{
        border:3px solid green;
        display:inline-block;
        padding:10px;
    }
label{
    display: block;
}
input{
    display: block;
    margin-bottom: 20px;
}

#pop{
    border:2px groove blue;
     border-radius: 20px;

     ;
}

</style>
<div>
<form method="post">
    <label >Database Name:</label>
    <input type="text" id="dbname" name="dbname">

    <label >Server Name:</label>
    <input type="text" id="servername" name="servername">

    <label >Port Number:</label>
    <input type="number" id="portno" name="portno">

    <label >User Name:</label>
    <input type="text" id="username" name="username">

    <label >Password:</label>
    <input type="password" id="password" name="password">

    <input type="submit" value="Proceed" name="submit">
</form>
</div>

<?php
// checking if form is submitted.

if(isset($_POST['submit'])){


 
    // get values from form and assign to  variables
    $db_name =   $_POST['dbname'];
    $server_name=$_POST['servername'];
    $user_name=$_POST["username"];
    $pass_word= $_POST['password' ];
    $port_number=$_POST['portno'];

    $db_name = htmlspecialchars($_POST['db_name']); // omitting special characters , before this sanitization was used now it is depcrecated



    // now we need to execute a query to create database based on credentials provided above.

    ### Create a new PDO connection

     

    /* Establish a connection to the database using the PDO (PHP Data Objects) library
     PDO is a database abstraction layer that provides a consistent interface for
     interacting with different database management systems .This line creates a new PDO
     object and assigns it to the $connection variable, which can be used to execute SQL
     queries and perform other database operations */


/*
PDO Extension:

The PDO extension is a compiled piece of software that adds functionalities to the PHP interpreter.
It provides a set of pre-defined functions and classes specifically designed for interacting with databases.
PDO Classes and Functions:

When you use the PDO extension in your code, you're interacting with the classes and functions it provides.
The core class is PDO itself, which represents a database connection.
*/

     
     
     
//         try {
//             // Connect to the MySQL server

//             $dsn = "mysql:host=$server_name;port=$port_number";
//             $connection = new PDO($dsn, $user_name, $pass_word);
//             $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       
//             /* setAttribute: This is a method provided by the PDO class that allows you to configure various
//              aspects of the connection.
//              PDO::ERRMODE_EXCEPTION            // others are warning and silent
//              This mode is generally considered the most secure and reliable way to handle PDO errors.
//             When you set the error mode to PDO::ERRMODE_EXCEPTION, any error that occurs during database
//             operations will throw a PDOException.
// */

//             // Create database (if it doesn't exist)
//             $sql = "CREATE DATABASE IF NOT EXISTS ?";
//             $stmt = $connection->prepare($sql);
//             $stmt->mysqli("s", $db_name);
//             $connection->exec($stmt);

//             /*
//             Prepared statements offer a secure way to execute SQL queries
//             by separating the query itself from the user-provided data.
//             This makes it more difficult for attackers to inject malicious code.
//             */



//             echo "<div id='pop'>Database $db_name created successfully</div>" ;

   

//         } catch(PDOException $e) {
//           echo "Error creating database: " . $e->getMessage();
//         }

//         /*
//         getMessage(): This is a method provided by the Exception class
//          (the base class for most exceptions in PHP).
//          It returns a string that describes the error or exception
//          that occurred.
//         */
       
//       //  $connection=null; // Close connection

//     }
try {
    // ✅ Correct DSN
    $dsn = "mysql:host=$server_name;port=$port_number";

    // ✅ Connect using PDO
    $connection = new PDO($dsn, $user_name, $pass_word);
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // ✅ Sanitize DB name manually (no prepared statements for DB names)
    $safe_db_name = preg_replace('/[^a-zA-Z0-9_]/', '', $db_name);

    // ✅ Run SQL to create DB
    $sql = "CREATE DATABASE IF NOT EXISTS `$safe_db_name`";
    $connection->exec($sql);

    echo "<div id='pop'>✅ Database <b>$safe_db_name</b> created successfully!</div>";
} catch (PDOException $e) {
    echo "<div id='pop' style='color:red; border-color:red;'>❌ Error creating database: " . $e->getMessage() . "</div>";
}
}
?>
       