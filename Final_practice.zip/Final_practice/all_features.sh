#!/bin/bash

# Create the main directory
mkdir simple-project

# Navigate into the main directory
cd simple-project

# Create the files
touch index.php dashboard.php login.php logout.php style.css

# Print the directory structure (optional)
echo "Directory structure created:"
tree .
