<?php
session_start();

$db_host = 'localhost';
$db_user = 'root';
$db_pass = 'mi';
$db_name = 'simple_app';

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$conn) {
    die('DB Connection failed: ' . mysqli_connect_error());
}
?>