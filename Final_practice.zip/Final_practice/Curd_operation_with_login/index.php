<?php
require 'config.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username']);
    $e = trim($_POST['email']);
    $p = $_POST['password'];

    if ($u === '' || $e === '' || strlen($p) < 6) {
        $error = 'Please fill all fields; password ≥ 6 chars.';
    } else {
        // check duplicates
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$u, $e]);
        if ($stmt->fetch()) {
            $error = 'Username or email already taken.';
        } else {
            $hash = password_hash($p, PASSWORD_DEFAULT);
            $pdo->prepare("INSERT INTO users (username,email,password) VALUES (?,?,?)")
                ->execute([$u, $e, $hash]);
            header('Location: login.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Sign Up</title>
  <link rel="stylesheet" href="assets/style.css">
  <script src="assets/script.js" defer></script>
</head>
<body>
  <div class="container">
    <h2>Create Account</h2>
    <?php if($error): ?><div class="alert"><?=htmlspecialchars($error)?></div><?php endif; ?>
    <form method="POST" onsubmit="return validateSignup()">
      <div id="error-msg" class="alert" style="display: none;"></div>
      <input type="text" id="username" name="username" placeholder="Username">
      <input type="email" id="email" name="email" placeholder="Email">
      <input type="password" id="password" name="password" placeholder="Password">
      <button type="submit">Sign Up</button>
    </form>
    <p style="text-align:center;margin-top:10px;">
      Already have an account? <a href="login.php">Log In</a>
    </p>
  </div>
</body>
</html>
