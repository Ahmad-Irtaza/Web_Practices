// This will trigger the search whenever the user types something
document.getElementById('search-input').addEventListener('keyup', function() {
    const searchTerm = this.value;
    
    // Only search when there is something in the input
    if (searchTerm.length > 0) {
      window.location.href = '?search=' + searchTerm;
    }
  });
  