<!-- CREATE DATABASE search_example;

USE search_example;

CREATE TABLE items (
  id INT AUTO_INCREMENT PRIMARY KEY,    
  name VARCHAR(255) NOT NULL
);

-- Add some sample data
INSERT INTO items (name) VALUES ('Apple');
INSERT INTO items (name) VALUES ('Banana');
INSERT INTO items (name) VALUES ('Cherry');
INSERT INTO items (name) VALUES ('Date');
INSERT INTO items (name) VALUES ('Grape');
INSERT INTO items (name) VALUES ('Lemon'); -->


<?php
$host = 'localhost';
$dbname = 'search_example';
$username = 'root';
$password = 'mi'; // Add your MySQL password if any

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
