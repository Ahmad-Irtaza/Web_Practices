<?php

// =========================================
// ✅ SECTION 1: Basic Route Setup
// =========================================
// Define routes in routes/web.php

use Illuminate\Support\Facades\Route;

// Basic route returning a view
Route::get('/', function () {
    return view('welcome');
});

// Route with a parameter
Route::get('/user/{id}', function ($id) {
    return "User ID: " . $id;
});

// Route with a controller method
Route::get('/home', 'HomeController@index');

// =========================================
// ✅ SECTION 2: Controller Setup
// =========================================
// Define a basic controller (Artisan command: php artisan make:controller HomeController)
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        return view('home');  // Render 'home.blade.php'
    }
}

// =========================================
// ✅ SECTION 3: Blade Views
// =========================================
// Define Blade template (resources/views/home.blade.php)

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home Page</title>
</head>
<body>
    <h1>Welcome to the Home Page</h1>
    <p>Current Date: {{ date('Y-m-d') }}</p>
</body>
</html>

// =========================================
// ✅ SECTION 4: Form Handling with Validation
// =========================================
// Route for displaying the form (routes/web.php)

Route::get('/contact', function () {
    return view('contact');
});

// Route to handle form submission (routes/web.php)

Route::post('/contact', function (Request $request) {
    $validated = $request->validate([
        'name' => 'required|max:255',
        'email' => 'required|email',
        'message' => 'required|max:1000',
    ]);

    // Process the form data (for example, store it or send an email)
    return back()->with('success', 'Thank you for your message!');
});

// Blade view for the form (resources/views/contact.blade.php)

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Form</title>
</head>
<body>
    <h1>Contact Us</h1>

    @if (session('success'))
        <p>{{ session('success') }}</p>
    @endif

    <form method="POST" action="/contact">
        @csrf
        <input type="text" name="name" placeholder="Your Name">
        <input type="email" name="email" placeholder="Your Email">
        <textarea name="message" placeholder="Your Message"></textarea>
        <button type="submit">Send</button>
    </form>
</body>
</html>

// =========================================
// ✅ SECTION 5: Database Operations
// =========================================
// Model (Create a model: php artisan make:model Post)

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    use HasFactory;

    protected $fillable = ['title', 'content'];
}

// Controller method to interact with the database (app/Http/Controllers/PostController.php)

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    // Show all posts
    public function index()
    {
        $posts = Post::all();
        return view('posts.index', compact('posts'));
    }

    // Show form to create a new post
    public function create()
    {
        return view('posts.create');
    }

    // Store a new post
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|max:255',
            'content' => 'required',
        ]);

        Post::create($validated);

        return redirect()->route('posts.index');
    }
}

// Routes for the controller (routes/web.php)

Route::resource('posts', PostController::class);

// Blade view to display posts (resources/views/posts/index.blade.php)

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Posts</title>
</head>
<body>
    <h1>Posts</h1>

    <ul>
        @foreach ($posts as $post)
            <li>{{ $post->title }} - {{ $post->content }}</li>
        @endforeach
    </ul>
    <a href="{{ route('posts.create') }}">Create a new post</a>
</body>
</html>

// Blade view to create a new post (resources/views/posts/create.blade.php)

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Post</title>
</head>
<body>
    <h1>Create a New Post</h1>

    <form method="POST" action="{{ route('posts.store') }}">
        @csrf
        <input type="text" name="title" placeholder="Post Title" required>
        <textarea name="content" placeholder="Post Content" required></textarea>
        <button type="submit">Save Post</button>
    </form>
</body>
</html>

// =========================================
// ✅ SECTION 6: Middleware Example (Authentication)
// =========================================
// Create authentication middleware (php artisan make:middleware Authenticate)

// app/Http/Middleware/Authenticate.php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Authenticate
{
    public function handle(Request $request, Closure $next)
    {
        if (Auth::check()) {
            return $next($request);
        }

        return redirect('/login');
    }
}

// Add middleware to routes (routes/web.php)

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    });
}

// =========================================
// ✅ SECTION 7: Authentication (Login/Logout)
// =========================================
// Use Laravel built-in Auth routes for handling authentication

// Generate authentication scaffolding (php artisan make:auth) or use built-in methods

// Routes in routes/web.php

Auth::routes();

// =========================================
// ✅ SECTION 8: CSRF Protection
// =========================================
// CSRF Token in forms
// Blade view with CSRF token (resources/views/form.blade.php)

<form method="POST" action="/submit-form">
    @csrf
    <input type="text" name="input_data" required>
    <button type="submit">Submit</button>
</form>

// =========================================
// ✅ SECTION 9: Laravel Artisan Commands
// =========================================

// 1. **Create a New Laravel Project**
// Command: composer create-project --prefer-dist laravel/laravel project_name
// Description: Creates a new Laravel project directory.

// 2. **Serve the Application**
// Command: php artisan serve
// Description: Starts a development server at http://127.0.0.1:8000.

// 3. **Generate a Controller**
// Command: php artisan make:controller ControllerName
// Description: Creates a new controller in the app/Http/Controllers directory.

// 4. **Generate a Model**
// Command: php artisan make:model ModelName
// Description: Creates a new Eloquent model in the app/Models directory.

// 5. **Generate a Migration**
// Command: php artisan make:migration migration_name
// Description: Creates a new migration file for database schema changes.

// 6. **Run Migrations**
// Command: php artisan migrate
// Description: Runs all pending migrations to update the database schema.

// 7. **Rollback the Last Migration**
// Command: php artisan migrate:rollback
// Description: Rolls back the most recent batch of migrations.

// 8. **Generate a Seeder**
// Command: php artisan make:seeder SeederName
// Description: Creates a new database seeder file.

// 9. **Run Seeders**
// Command: php artisan db:seed
// Description: Seeds the database with data using seeder classes.

// 10. **Clear Application Cache**
// Command: php artisan cache:clear
// Description: Clears the application cache.

// 11. **Generate a Middleware**
// Command: php artisan make:middleware MiddlewareName
// Description: Creates a new middleware file.

// 12. **Generate a Request Validation**
// Command: php artisan make:request RequestName
// Description: Creates a new form request validation class.

// 13. **Generate a Command**
// Command: php artisan make:command CommandName
// Description: Creates a new Artisan command file.

// 14. **Route List**
// Command: php artisan route:list
// Description: Displays a list of all registered routes in the application.

// 15. **Generate a Factory**
// Command: php artisan make:factory FactoryName
// Description: Creates a new factory file for generating model data.

// 16. **Generate a Test**
// Command: php artisan make:test TestName
// Description: Creates a new test file in the tests directory.

// 17. **Run Tests**
// Command: php artisan test
// Description: Runs all tests defined in the tests directory.

// 18. **Generate Authentication Scaffolding (Login, Register)**
// Command: php artisan ui bootstrap --auth
// Description: Generates the login, register, and home views for authentication.

// 19. **Clear View Cache**
// Command: php artisan view:clear
// Description: Clears all compiled Blade views.

// 20. **Clear Config Cache**
// Command: php artisan config:clear
// Description: Clears the configuration cache.

// 21. **Optimize the Application**
// Command: php artisan optimize
// Description: Optimizes the application for better performance by caching routes, config, etc.

// 22. **Tinker (Interactive REPL)**
// Command: php artisan tinker
// Description: Opens an interactive shell for running Laravel commands and accessing the application directly.

// =========================================
// ✅ END OF FILE
// =========================================

