// Live filter by name
document.getElementById('search').addEventListener('input', e => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#student-table tbody tr').forEach(row => {
      const name = row.children[0].textContent.toLowerCase();
      row.style.display = name.includes(term) ? '' : 'none';
    });
  });
  