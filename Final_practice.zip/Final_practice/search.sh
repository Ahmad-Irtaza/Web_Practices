#!/bin/bash

# Create the main directory
mkdir search-app

# Navigate into the main directory
cd search-app

# Create the files
touch index.php style.css script.js db.php

# Print the directory structure (optional)
echo "Directory structure created:"
tree .
