<?php
session_start();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username']);
    $p = $_POST['password'];

    if (
        isset($_SESSION['users'][$u]) &&
        password_verify($p, $_SESSION['users'][$u])
    ) {
        $_SESSION['username'] = $u;
        header('Location: Home.php');
        exit;
    } else {
        $error = 'Invalid username or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
      body {
    font-family: Arial, sans-serif;
    background-color: black;
    color: white;
    text-align: center;
    padding: 50px;
    /* display: flex; */
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    margin: 0;
}
    h1 {
        color: white;
        margin-bottom: 20px;
        display: flex;
        justify-content: center;
        shadow: 0 0 10px rgb(98, 70, 70);

    }
    form {
        display: flex;
        flex-direction: column;
        align-items: center;
        background-color: #333;
        padding: 10px;
        border-radius: 5px;
        border-color: #555;
        box-shadow: 0 0 10px rgb(246, 246, 246);
    }
    label {
        margin-bottom: 10px;
        color: white;
    }
    
    #username, #password {
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #555;
        border-radius: 5px;
        width: 200px;
    }
    input[type="submit"] {
        background-color: #555;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
    }
    #a{
        text-decoration: none;
        color: white;
        padding: 100px;
        margin: 10px;
    }
    </style>
</head>
<body>
  <h1>Log in</h1>
  <?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  <form action="login.php" method="POST">
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" required>

    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required>    <input type="submit" value="Login">
  </form>
  <br>
  <a href="signup.php">Don’t have an account? Sign up</a>
</body>
</html>
