

<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
    <style>
        /* Basic styling for our login page */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        
        .login-container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 300px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }
        
        .login-container form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .login-container input[type="text"], .login-container 
input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        
        .login-container input[type="submit"] {
            background-color: #4CAF50;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        
        .login-container input[type="submit"]:hover {
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
    <div class="login-container">
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            <h2>Login</h2>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required 
autofocus>
            
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            
            <input type="submit" value="Login">
        </form>
    </div>

<?php
if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the username and password are valid
    $query = "SELECT * FROM users WHERE username='$username' AND 
password=PASSWORD('$password')";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        // User is logged in, set session variables
        $_SESSION['logged_in'] = true;
        $_SESSION['username'] = $username;

        header('Location: dashboard.php');
        exit;
    } else {
        echo '<p class="error">Invalid username or password.</p>';
    }
}
?>
<script>


$(document).ready(function() {
    $(".login-container").animate({ opacity: 0 }, 500);
    setTimeout(function() {
        $(".login-container").animate({ opacity: 1 }, 500);
    }, 500);

    // Add a fade-out effect when submitting the form
    $('input[type="submit"]').click(function() {
        $(this).animate({ opacity: 0 }, 200, function() {
            $(this).hide();
        });
    });
});
</script>
</body>
</html>
