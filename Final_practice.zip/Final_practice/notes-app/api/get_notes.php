<?php
header('Content-Type: application/json');
require '../vendor/autoload.php';            // install mongodb/mongodb via composer

$client = new MongoDB\Client("mongodb://localhost:27017");
$collection = $client->notes_app->notes;    // database=notes_app, collection=notes

$cursor = $collection->find([], ['sort'=>['_id'=>-1]]);
echo json_encode($cursor->toArray());
