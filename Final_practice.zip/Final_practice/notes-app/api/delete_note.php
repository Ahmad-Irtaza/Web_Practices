<?php
header('Content-Type: application/json');
require '../vendor/autoload.php';

$id = $_GET['id'] ?? '';
if (!$id) {
  http_response_code(400);
  echo json_encode(['error'=>'No ID']);
  exit;
}

$client = new MongoDB\Client("mongodb://localhost:27017");
$collection = $client->notes_app->notes;
$collection->deleteOne(['_id'=>new MongoDB\BSON\ObjectId($id)]);

echo json_encode(['deleted'=>true]);
