#!/bin/bash

# Create the main directory
mkdir my_modular_site

# Navigate into the main directory
cd my_modular_site

# Create the 'assets' directory
mkdir assets

# Navigate into the 'assets' directory
cd assets

# Create the 'css' directory
mkdir css

# Navigate into the 'css' directory
cd css

# Create the style.css file
touch style.css

# Navigate back to the 'assets' directory
cd ../

# Create the 'js' directory
mkdir js

# Navigate into the 'js' directory
cd js

# Create the script.js file
touch script.js

# Navigate back to the main directory
cd ../../

# Create the 'includes' directory
mkdir includes

# Navigate into the 'includes' directory
cd includes

# Create the include files
touch footer.php navbar.php sidebar.php

# Navigate back to the main directory
cd ../

# Create the main PHP files
touch index.php about.php contact.php

# Print the directory structure (optional)
echo "Directory structure created:"
tree .
