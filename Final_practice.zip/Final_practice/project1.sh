#!/bin/bash

# Create the main directory
mkdir notes-app

# Navigate into the main directory
cd notes-app

# Create the 'public' directory
mkdir public

# Navigate into the 'public' directory
cd public

# Create the files within the 'public' directory
touch index.html style.css script.js

# Navigate back to the main directory
cd ..

# Create the 'api' directory
mkdir api

# Navigate into the 'api' directory
cd api

# Create the files within the 'api' directory
touch get_notes.php add_note.php delete_note.php

# Navigate back to the main directory
cd ..

# Print the directory structure (optional)
echo "Directory structure created:"
tree .
