#!/bin/bash

# Create the main project folder
mkdir your-project-folder

# Navigate into the project folder
cd your-project-folder

# Create the PHP files
touch config.php signup.php login.php dashboard.php logout.php process_item.php

# Create the 'assets' directory
mkdir assets

# Navigate into the 'assets' directory
cd assets

# Create the CSS and JS files
touch style.css script.js

# Navigate back to the main project folder
cd ../

# Print the directory structure (optional)
echo "Directory structure created:"
tree .
