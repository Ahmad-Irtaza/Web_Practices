<?php
include 'includes/auth.php';   // redirects if not logged in
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard | MySite</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
  <?php include 'includes/navbar.php'; ?>

  <div class="container">
    <?php include 'includes/sidebar.php'; ?>
    <main class="main-content">
      <h1>Welcome, User #<?= $_SESSION['user'] ?></h1>
      <p>This is your protected dashboard.</p>
      <p><a href="logout.php">Log out</a></p>
    </main>
  </div>

  <?php include 'includes/footer.php'; ?>
  <script src="assets/js/script.js"></script>
</body>
</html>
