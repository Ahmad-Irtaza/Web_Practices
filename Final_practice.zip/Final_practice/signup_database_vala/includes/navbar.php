<!-- includes/navbar.php -->
<nav class="navbar">
  <div class="logo"><a href="index.php">MySite</a></div>
  <ul class="nav-links">
    <li><a href="dashboard.php">Home</a></li>
    <li><a href="about.php">About</a></li>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="logout.php">Log out</a></li>

  </ul>
  <button class="nav-toggle" id="nav-toggle">☰</button>
</nav>
