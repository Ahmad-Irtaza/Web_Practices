<?php
// about.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>About | MySite</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

  <?php include 'includes/navbar.php'; ?>

  <div class="container">
    <?php include 'includes/sidebar.php'; ?>
    <main class="main-content">
      <h1>About Us</h1>
      <p>Explain who you are, what this project is for, etc.</p>
    </main>
  </div>

  <?php include 'includes/footer.php'; ?>
  <script src="assets/js/script.js"></script>
</body>
</html>
