<?php
// index.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Home | MySite</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

  <?php include 'includes/navbar.php'; ?>

  <div class="container">
    <?php include 'includes/sidebar.php'; ?>
    <main class="main-content">
      <h1>Welcome to My Modular Site</h1>
      <p>This is the home page. Use these components in any future project!</p>
    </main>
  </div>

  <?php include 'includes/footer.php'; ?>
  <script src="assets/js/script.js"></script>
</body>
</html>
