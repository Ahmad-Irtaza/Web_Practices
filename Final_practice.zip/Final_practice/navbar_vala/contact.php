<?php
// contact.php
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name    = htmlspecialchars(trim($_POST['name']));
  $email   = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
  $messageBody = htmlspecialchars(trim($_POST['message']));

  if ($name && $email && $messageBody) {
    // Here you could mail() or save to DB. We'll just simulate success:
    $message = 'Thank you, your message has been received!';
  } else {
    $message = 'Please fill in all fields correctly.';
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Contact | MySite</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

  <?php include 'includes/navbar.php'; ?>

  <div class="container">
    <?php include 'includes/sidebar.php'; ?>
    <main class="main-content">
      <h1>Contact Us</h1>
      <?php if ($message): ?>
        <p><em><?= $message ?></em></p>
      <?php endif; ?>
      <form action="" method="POST" onsubmit="return validateForm()">
        <label>Name:</label><br>
        <input type="text" name="name" id="name"><br><br>
        <label>Email:</label><br>
        <input type="email" name="email" id="email"><br><br>
        <label>Message:</label><br>
        <textarea name="message" id="message" rows="5"></textarea><br><br>
        <button type="submit">Send</button>
      </form>
    </main>
  </div>

  <?php include 'includes/footer.php'; ?>
  <script src="assets/js/script.js"></script>
  <script>
    // Simple vanilla JS form validation
    function validateForm() {
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const msg = document.getElementById('message').value.trim();
      if (!name || !email || !msg) {
        alert('All fields are required.');
        return false;
      }
      return true;
    }
  </script>
</body>
</html>
