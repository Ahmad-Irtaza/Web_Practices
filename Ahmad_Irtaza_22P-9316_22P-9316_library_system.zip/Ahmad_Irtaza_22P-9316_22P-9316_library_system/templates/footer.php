<?php
function renderFooterAlt() { ?>
        </main>
    </body>
    </html>
<?php }
?>