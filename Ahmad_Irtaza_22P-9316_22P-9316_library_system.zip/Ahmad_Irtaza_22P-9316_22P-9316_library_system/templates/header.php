<?php
require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/functions.php';

function renderHeaderAlt($page_title = 'Library System') {
    $isLoggedIn = isLoggedInAlt();
    $username = $_SESSION['username_alt'] ?? 'Guest';
    $role = $_SESSION['role_alt'] ?? null;
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($page_title); ?></title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <header>
            <h1>Library System</h1>
            <nav>
                <ul>
                    <?php if ($isLoggedIn): ?>
                        <li>Welcome, <?php echo htmlspecialchars($username); ?>!</li>
                        <li><a href="index.php?action=dashboard">Dashboard</a></li>
                        <li><a href="index.php?action=request_book_form">Request Book</a></li>
                        <?php if ($role === 'admin' || $role === 'super_admin'): ?>
                             <li><a href="admin.php">Admin Panel</a></li>
                        <?php endif; ?>
                        <li><a href="index.php?action=logout">Logout</a></li>
                    <?php else: ?>
                        <li><a href="index.php?action=login_form">Login</a></li>
                        <li><a href="index.php?action=register_form">Register</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </header>
        <main>
            <?php displayFlashMessageAlt('status_message'); displayFlashMessageAlt('error_message'); ?>
    <?php
}
?>