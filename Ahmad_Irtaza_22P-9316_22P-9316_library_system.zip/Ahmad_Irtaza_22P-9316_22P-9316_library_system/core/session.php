<?php
if (!isset($_SESSION['users_alt'])) {
    $_SESSION['users_alt'] = [];
}
if (!isset($_SESSION['books_alt'])) {
    $_SESSION['books_alt'] = [];
}
if (!isset($_SESSION['requests_alt'])) {
    $_SESSION['requests_alt'] = [];
}
if (!isset($_SESSION['api_limits_alt'])) {
     $_SESSION['api_limits_alt'] = [];
}
if (!isset($_SESSION['next_user_id_alt'])) { $_SESSION['next_user_id_alt'] = 1; }
if (!isset($_SESSION['next_book_id_alt'])) { $_SESSION['next_book_id_alt'] = 1; }
if (!isset($_SESSION['next_request_id_alt'])) { $_SESSION['next_request_id_alt'] = 1; }
?>