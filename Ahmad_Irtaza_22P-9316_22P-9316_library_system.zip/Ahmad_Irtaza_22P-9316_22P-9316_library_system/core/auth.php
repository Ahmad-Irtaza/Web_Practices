<?php
require_once 'functions.php'; // For isLoggedInAlt

function isLoggedInAlt(): bool {
    return isset($_SESSION['user_id_alt']);
}

function hasRoleAlt(string $role): bool {
    return isLoggedInAlt() && isset($_SESSION['role_alt']) && $_SESSION['role_alt'] === $role;
}
?>