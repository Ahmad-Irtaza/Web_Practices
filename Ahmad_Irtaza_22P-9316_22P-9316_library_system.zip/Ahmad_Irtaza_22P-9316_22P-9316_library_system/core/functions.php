<?php
function sanitizeInputAlt(string $data): string {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

function redirectAlt(string $url): void {
    header("Location: " . $url);
    exit;
}

function setFlashMessageAlt(string $name, string $message, string $type = 'info'): void {
    $_SESSION[$name . '_alt'] = $message;
    $_SESSION[$name . '_type_alt'] = $type;
}

function displayFlashMessageAlt(string $name): void {
    if (isset($_SESSION[$name . '_alt'])) {
        echo '<div class="message ' . ($_SESSION[$name . '_type_alt'] ?? 'info') . '">' . htmlspecialchars($_SESSION[$name . '_alt']) . '</div>';
        unset($_SESSION[$name . '_alt'], $_SESSION[$name . '_type_alt']);
    }
}
?>