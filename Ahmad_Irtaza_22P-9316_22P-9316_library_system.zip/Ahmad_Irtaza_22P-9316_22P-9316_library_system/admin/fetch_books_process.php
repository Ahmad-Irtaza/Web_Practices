<?php
require_once 'index.php'; // Include to ensure auth and functions are available

if (!$isSuperAdmin || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirectAdminAlt('index.php?action=admin_dashboard');
}

$limit = 5;
$today_dt = date('Y-m-d');
$limit_info = $_SESSION['api_limits_alt'][$currentUserId] ?? ['count' => 0, 'date' => ''];
$req_today = ($limit_info['date'] == $today_dt) ? $limit_info['count'] : 0;
$can_fetch = ($req_today < $limit);

if ($can_fetch) {
    $cats = ['app development' => 'app+development', 'mobile development' => 'mobile+development', 'AI' => 'artificial+intelligence'];
    $api_url_base = 'https://www.googleapis.com/books/v1/volumes?q=';
    $max_res = 10;
    $added = 0;
    $errors = [];
    foreach ($cats as $cat_name => $term) {
        $url = $api_url_base . $term . '&maxResults=' . $max_res . '&printType=books';
        $ctx = stream_context_create(['http' => ['ignore_errors' => true, 'timeout' => 10]]);
        $json = @file_get_contents($url, false, $ctx);
        if ($json === false || !isset($http_response_header) || strpos($http_response_header[0], '200 OK') === false) {
            $errors[] = "Fetch failed for '{$cat_name}'.";
            error_log("API Fetch Error for {$cat_name}: " . ($http_response_header[0] ?? 'Unknown'));
            continue;
        }
        $data = json_decode($json, true);
        if (!$data || !isset($data['items'])) {
            $errors[] = "No/Bad data for '{$cat_name}'.";
            continue;
        }
        foreach ($data['items'] as $item) {
            if (!isset($item['volumeInfo']['title'])) continue;
            $v = $item['volumeInfo'];
            $id = $item['id'] ?? null;
            $t = $v['title'];
            $a = implode(', ', $v['authors'] ?? ['Unknown']);
            $exists = false;
            foreach ($_SESSION['books_alt'] as $bdata) {
                if (($id && $bdata['api_book_id'] == $id) || ($bdata['title'] == $t && $bdata['author'] == $a)) {
                    $exists = true;
                    break;
                }
            }
            if ($exists) continue;
            $new_book_id = $_SESSION['next_book_id_alt']++;
            $_SESSION['books_alt'][$new_book_id] = ['title' => $t, 'author' => $a, 'category' => $cat_name, 'api_book_id' => $id, 'added_at' => date('Y-m-d H:i:s')];
            $added++;
        }
    }
    $new_count = ($limit_info['date'] == $today_dt) ? $limit_info['count'] + 1 : 1;
    $_SESSION['api_limits_alt'][$currentUserId] = ['count' => $new_count, 'date' => $today_dt];

    if ($added > 0) setFlashMessageAdminAlt('status_message', "Added {$added} new books.", 'success');
    else setFlashMessageAdminAlt('status_message', "No new books added.", 'info');
    if (!empty($errors)) setFlashMessageAdminAlt('error_message', "Fetch had issues: " . implode(' ', $errors), 'error');
} else {
    setFlashMessageAdminAlt('error_message', 'API limit reached.', 'error');
}
redirectAdminAlt('index.php?action=fetch_books_form');
?>