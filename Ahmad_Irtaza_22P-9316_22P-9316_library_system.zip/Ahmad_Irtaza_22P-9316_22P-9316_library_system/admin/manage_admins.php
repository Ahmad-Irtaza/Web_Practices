<?php
require_once 'index.php'; // Include to ensure auth and functions are available

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_admin'])) {
        $user = sanitizeInputAdminAlt($_POST['username'] ?? '');
        $email = sanitizeInputAdminAlt($_POST['email'] ?? '');
        $pass = $_POST['password'] ?? '';
        $err = [];
        if (empty($user) || strlen($user) < 3) $err[] = 'Username short.';
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $err[] = 'Invalid email.';
        if (empty($pass) || strlen($pass) < 6) $err[] = 'Password short.';
        if (empty($err)) {
            foreach ($_SESSION['users_alt'] as $udata) {
                if (strtolower($udata['username']) === strtolower($user) || strtolower($udata['email']) === strtolower($email)) {
                    $err[] = 'User/Email exists.';
                    break;
                }
            }
        }
        if (empty($err)) {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            if (!$hash) $err[] = 'Hash failed.';
            else {
                $new_admin_id = $_SESSION['next_user_id_alt']++;
                $_SESSION['users_alt'][$new_admin_id] = ['username' => $user, 'email' => $email, 'password_hash' => $hash, 'role' => 'admin', 'created_at' => date('Y-m-d H:i:s')];
                setFlashMessageAdminAlt('status_message', 'Admin added.', 'success');
            }
        }
        if (!empty($err)) {
            setFlashMessageAdminAlt('error_message', implode(' ', $err), 'error');
            $_SESSION['add_admin_form_data_alt'] = $_POST;
        }
        redirectAdminAlt('index.php?action=manage_admins');
    } elseif (isset($_POST['delete_admin']) && isset($_POST['user_id'])) {
        $uid = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
        if ($uid && isset($_SESSION['users_alt'][$uid]) && $_SESSION['users_alt'][$uid]['role'] === 'admin') {
            unset($_SESSION['users_alt'][$uid]);
            setFlashMessageAdminAlt('status_message', 'Admin deleted.', 'success');
        } else {
            setFlashMessageAdminAlt('error_message', 'Delete failed (not found/not admin).', 'error');
        }
        redirectAdminAlt('index.php?action=manage_admins');
    }
}

renderHeaderAdminAlt('Manage Admins');
$add_form = $_SESSION['add_admin_form_data_alt'] ?? [];
unset($_SESSION['add_admin_form_data_alt']);
?>
<h2>Manage Admins</h2>
<hr>
<h3>Add New Admin</h3>
<form action="index.php" method="POST">
    <input type="hidden" name="action" value="manage_admins">
    <div><label>Username:</label><input type="text" name="username" required value="<?php echo htmlspecialchars($add_form['username'] ?? ''); ?>"></div>
    <div><label>Email:</label><input type="email" name="email" required value="<?php echo htmlspecialchars($add_form['email'] ?? ''); ?>"></div>
    <div><label>Password:</label><input type="password" name="password" required></div>
    <div><button type="submit" name="add_admin">Add Admin</button></div>
</form>
<hr>
<h3>Current Admins</h3>
<?php
$admins_list = [];
foreach ($_SESSION['users_alt'] as $uid => $udata) {
    if ($udata['role'] === 'admin') {
        $admins_list[$uid] = $udata;
    }
}
?>
<?php if (empty($admins_list)): echo "<p>No admins found.</p>"; else: ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($admins_list as $uid => $admin): ?>
                <tr>
                    <td><?php echo $uid; ?></td>
                    <td><?php echo htmlspecialchars($admin['username']); ?></td>
                    <td><?php echo htmlspecialchars($admin['email']); ?></td>
                    <td>
                        <form action="index.php" method="POST" style="display:inline;">
                            <input type="hidden" name="action" value="manage_admins">
                            <input type="hidden" name="user_id" value="<?php echo $uid; ?>">
                            <button type="submit" name="delete_admin" onclick="return confirm('Delete Admin?');" style="color:red;">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
<?php
// renderFooterAdminAlt() will be called from index.php
?>