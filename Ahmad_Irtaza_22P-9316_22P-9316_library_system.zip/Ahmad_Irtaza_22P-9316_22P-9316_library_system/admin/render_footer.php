<?php
function renderFooterAdminAlt() { ?> </main></body></html> <?php }
renderFooterAdminAlt();
?>