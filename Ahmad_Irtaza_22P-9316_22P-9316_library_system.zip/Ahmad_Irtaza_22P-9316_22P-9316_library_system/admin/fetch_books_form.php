<?php
require_once 'index.php'; // Include to ensure auth and functions are available

renderHeaderAdminAlt('Fetch Books API');
$limit = 5;
$today_dt = date('Y-m-d');
$limit_info = $_SESSION['api_limits_alt'][$currentUserId] ?? ['count' => 0, 'date' => ''];
$req_today = ($limit_info['date'] == $today_dt) ? $limit_info['count'] : 0;
$can_fetch = ($req_today < $limit);
?>
<h2>Fetch Books from Google Books API</h2>
<p>Fetch books for App Dev, Mobile Dev, AI.</p>
<p>Limit: <?php echo $req_today; ?> / <?php echo $limit; ?> attempts today.</p>
<?php if (!$can_fetch): ?>
    <p class='message error'>Daily API limit reached.</p>
<?php else: ?>
    <form action="index.php" method="POST">
        <input type="hidden" name="action" value="fetch_books_process">
        <button type="submit">Fetch Books Now</button>
    </form>
<?php endif; ?>
<?php
// renderFooterAdminAlt() will be called from index.php
?>