<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../core/functions.php';
require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/session.php';

function sanitizeInputAdminAlt(string $data): string { return sanitizeInputAlt($data); }
function redirectAdminAlt(string $url): void { redirectAlt($url); }
function isLoggedInAdminAlt(): bool { return isLoggedInAlt(); }
function hasRoleAdminAlt(string $role): bool { return hasRoleAlt($role); }
function setFlashMessageAdminAlt(string $name, string $message, string $type = 'info'): void { setFlashMessageAlt($name, $message, $type); }
function displayFlashMessageAdminAlt(string $name): void { displayFlashMessageAlt($name); }
function renderHeaderAdminAlt($page_title = 'Admin Panel') {
    $isLoggedIn = isLoggedInAdminAlt(); $username = $_SESSION['username_alt'] ?? 'Guest'; $role = $_SESSION['role_alt'] ?? null;
    ?> <!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title><link rel="stylesheet" href="../style.css"></head><body>
    <header><h1>Library System - Admin Panel</h1><nav><ul>
    <?php if ($isLoggedIn && ($role === 'admin' || $role === 'super_admin')): ?>
        <li>Welcome, <?php echo htmlspecialchars($username); ?> (<?php echo $role; ?>)!</li>
        <li><a href="index.php?action=admin_dashboard">Admin Dashboard</a></li>
        <li><a href="index.php?action=view_requests">View Requests</a></li>
        <?php if ($role === 'super_admin'): ?>
            <li><a href="index.php?action=manage_requests">Manage Requests</a></li>
            <li><a href="index.php?action=manage_users">Manage Users</a></li>
            <li><a href="index.php?action=manage_admins">Manage Admins</a></li>
            <li><a href="index.php?action=fetch_books_form">Fetch Books API</a></li>
        <?php endif; ?>
         <li><a href="../index.php?action=logout">Logout</a></li>
    <?php else: redirectAdminAlt('../index.php?action=login_form'); endif; ?>
    </ul></nav></header><main>
    <?php displayFlashMessageAdminAlt('status_message'); displayFlashMessageAdminAlt('error_message');
}
function renderFooterAdminAlt() { ?> </main></body></html> <?php }

if (!isLoggedInAdminAlt() || (!hasRoleAdminAlt('admin') && !hasRoleAdminAlt('super_admin'))) {
    setFlashMessageAdminAlt('login_error', 'Access denied.', 'error');
    redirectAdminAlt('../index.php?action=login_form');
}

$isSuperAdmin = hasRoleAdminAlt('super_admin');
$currentUserId = $_SESSION['user_id_alt'] ?? 0;

$action = $_REQUEST['action'] ?? 'admin_dashboard';

if ($action === 'admin_dashboard') {
    require 'dashboard.php';
} elseif ($action === 'view_requests') {
    require 'view_requests.php';
} elseif ($action === 'manage_requests') {
    require 'manage_requests.php';
} elseif ($action === 'manage_users') {
    require 'manage_users.php';
} elseif ($action === 'manage_admins') {
    require 'manage_admins.php';
} elseif ($action === 'fetch_books_form') {
    require 'fetch_books_form.php';
} elseif ($action === 'fetch_books_process') {
    require 'fetch_books_process.php';
} else {
    setFlashMessageAdminAlt('error_message', 'Invalid admin action.', 'error');
    header("Location: index.php?action=admin_dashboard");
    exit;
}

require_once 'render_footer.php'; // Separate file for footer rendering
?>