<?php
require_once 'config/config.php';
require_once 'core/functions.php';
require_once 'core/auth.php';
require_once 'core/session.php';
require_once 'templates/header.php';
require_once 'templates/footer.php';

$action = $_REQUEST['action'] ?? 'default';

if ($action === 'default') {
    if (isLoggedInAlt()) {
        $action = 'dashboard';
    } else {
        $action = 'login_form';
    }
}

if ($action === 'login_form') {
    require 'users/auth/login_form.php';
} elseif ($action === 'login_process') {
    require 'users/auth/login_process.php';
} elseif ($action === 'register_form') {
    require 'users/auth/register_form.php';
} elseif ($action === 'register_process') {
    require 'users/auth/register_process.php';
} elseif ($action === 'logout') {
    require 'users/auth/logout.php';
} elseif ($action === 'dashboard') {
    require 'users/dashboard.php';
} elseif ($action === 'request_book_form') {
    require 'users/request_book_form.php';
} elseif ($action === 'request_process') {
    require 'users/request_process.php';
} elseif ($action === 'cancel_request') {
    require 'users/cancel_request.php';
} else {
    if (isLoggedInAlt()) {
        header("Location: index.php?action=dashboard");
        exit;
    } else {
        header("Location: index.php?action=login_form");
        exit;
    }
}

require_once 'templates/footer.php'; // Ensure footer is included for all user-facing pages
?>