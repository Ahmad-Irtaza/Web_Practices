<?php
require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/functions.php';
require_once __DIR__ . '/../core/session.php';

if (!isLoggedInAlt() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirectAlt('../../index.php?action=login_form');
}

$request_id = filter_input(INPUT_POST, 'request_id', FILTER_VALIDATE_INT);
$user_id = $_SESSION['user_id_alt'];

if ($request_id && isset($_SESSION['requests_alt'][$request_id])) {
    if ($_SESSION['requests_alt'][$request_id]['user_id'] == $user_id && $_SESSION['requests_alt'][$request_id]['request_status'] === 'pending') {
        $_SESSION['requests_alt'][$request_id]['request_status'] = 'cancelled';
        $_SESSION['requests_alt'][$request_id]['last_updated_at'] = date('Y-m-d H:i:s');
        setFlashMessageAlt('status_message', 'Request cancelled.', 'success');
    } else {
        setFlashMessageAlt('error_message', 'Could not cancel request.', 'error');
    }
} else {
    setFlashMessageAlt('error_message', 'Invalid request ID.', 'error');
}
redirectAlt('../../index.php?action=dashboard');
?>