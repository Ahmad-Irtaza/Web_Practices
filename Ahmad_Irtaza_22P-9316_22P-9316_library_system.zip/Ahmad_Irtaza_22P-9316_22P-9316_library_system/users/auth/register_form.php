<?php
require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/functions.php';
require_once __DIR__ . '/../../templates/header.php';
require_once __DIR__ . '/../../templates/footer.php';

if (isLoggedInAlt()) {
    redirectAlt('index.php?action=dashboard');
}

renderHeaderAlt('Register');
?>
<h2>Register</h2>
<?php displayFlashMessageAlt('register_error'); ?>
<form action="index.php" method="POST">
    <input type="hidden" name="action" value="register_process">
    <div><label for="username">Username:</label><input type="text" id="username" name="username" required></div>
    <div><label for="email">Email:</label><input type="email" id="email" name="email" required></div>
    <div><label for="password">Password:</label><input type="password" id="password" name="password" required></div>
    <div><label for="confirm_password">Confirm Password:</label><input type="password" id="confirm_password" name="confirm_password" required></div>
    <div><button type="submit">Register</button></div>
</form>
<p>Have an account? <a href="index.php?action=login_form">Login here</a>.</p>
<?php
renderFooterAlt();
?>