<?php
require_once __DIR__ . '/../../core/functions.php';
require_once __DIR__ . '/../../core/session.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitizeInputAlt($_POST['username'] ?? '');
    $email = sanitizeInputAlt($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $errors = [];

    if (empty($username) || strlen($username) < 3) $errors[] = 'Username requires 3+ chars.';
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email.';
    if (empty($password) || strlen($password) < 6) $errors[] = 'Password requires 6+ chars.';
    if ($password !== $confirm_password) $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
         foreach ($_SESSION['users_alt'] as $user_data) {
             if (strtolower($user_data['username']) === strtolower($username) || strtolower($user_data['email']) === strtolower($email)) {
                 $errors[] = 'Username or Email already exists.';
                 break;
             }
         }
    }

    if (empty($errors)) {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        if (!$password_hash) {
             setFlashMessageAlt('register_error', 'Password hashing failed.', 'error');
             redirectAlt('index.php?action=register_form');
        }

        $role = (empty($_SESSION['users_alt'])) ? 'super_admin' : 'user';
        $new_user_id = $_SESSION['next_user_id_alt']++;

        $_SESSION['users_alt'][$new_user_id] = [
            'username' => $username,
            'email' => $email,
            'password_hash' => $password_hash,
            'role' => $role,
            'created_at' => date('Y-m-d H:i:s')
        ];

        $success_msg = ($role === 'super_admin') ? 'Super Admin account created! Please log in.' : 'Registration successful! Please log in.';
        setFlashMessageAlt('login_status', $success_msg, 'success');
        redirectAlt('index.php?action=login_form');

    } else {
        setFlashMessageAlt('register_error', implode('<br>', $errors), 'error');
        redirectAlt('index.php?action=register_form');
    }
} else {
    redirectAlt('index.php?action=register_form'); // Prevent direct access
}
?>