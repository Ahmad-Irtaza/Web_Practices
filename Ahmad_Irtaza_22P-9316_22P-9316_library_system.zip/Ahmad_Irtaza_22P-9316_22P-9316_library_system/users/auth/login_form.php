<?php
require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/functions.php';
require_once __DIR__ . '/../../templates/header.php';
require_once __DIR__ . '/../../templates/footer.php';

if (isLoggedInAlt()) {
    redirectAlt('index.php?action=dashboard');
}

renderHeaderAlt('Login');
?>
<h2>Login</h2>
<?php displayFlashMessageAlt('login_status'); displayFlashMessageAlt('login_error'); ?>
<form action="index.php" method="POST">
    <input type="hidden" name="action" value="login_process">
    <div><label for="username">Username/Email:</label><input type="text" id="username" name="username" required></div>
    <div><label for="password">Password:</label><input type="password" id="password" name="password" required></div>
    <div><button type="submit">Login</button></div>
</form>
<p>No account? <a href="index.php?action=register_form">Register here</a>.</p>
<?php
renderFooterAlt();
?>