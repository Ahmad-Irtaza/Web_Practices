<?php
require_once __DIR__ . '/../../core/functions.php';
require_once __DIR__ . '/../../core/session.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username_or_email = sanitizeInputAlt($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $user_found = null;

    if (empty($username_or_email) || empty($password)) {
        setFlashMessageAlt('login_error', 'Username/Email and Password required.', 'error');
        redirectAlt('index.php?action=login_form');
    }

    foreach ($_SESSION['users_alt'] as $user_id => $user_data) {
        if ( (strtolower($user_data['username']) === strtolower($username_or_email) || strtolower($user_data['email']) === strtolower($username_or_email)) ) {
             if (password_verify($password, $user_data['password_hash'])) {
                 $user_found = $user_data;
                 $user_found['user_id'] = $user_id;
                 break;
             }
        }
    }

    if ($user_found) {
        session_regenerate_id(true);
        $_SESSION['user_id_alt'] = $user_found['user_id'];
        $_SESSION['username_alt'] = $user_found['username'];
        $_SESSION['role_alt'] = $user_found['role'];
        redirectAlt('index.php?action=dashboard');
    } else {
        setFlashMessageAlt('login_error', 'Invalid credentials.', 'error');
        redirectAlt('index.php?action=login_form');
    }
} else {
    redirectAlt('index.php?action=login_form'); // Prevent direct access
}
?>