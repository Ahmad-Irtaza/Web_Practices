<?php
require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/functions.php';
require_once __DIR__ . '/../core/session.php';

if (!isLoggedInAlt() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirectAlt('../../index.php?action=login_form');
}

$user_id = $_SESSION['user_id_alt'];
$category = sanitizeInputAlt($_POST['category'] ?? '');
$book_id = filter_input(INPUT_POST, 'book_id', FILTER_VALIDATE_INT);
$uploaded_file_path = null;
$errors = [];

if (empty($category) || !in_array(strtolower($category), ['app development', 'mobile development', 'AI'])) $errors[] = 'Invalid category.';
if (empty($book_id) || !isset($_SESSION['books_alt'][$book_id])) $errors[] = 'Invalid book selected.';
elseif (strtolower($_SESSION['books_alt'][$book_id]['category']) !== strtolower($category)) $errors[] = 'Book does not match category.';

if (isset($_FILES['optional_file']) && $_FILES['optional_file']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['optional_file'];
    $max_size = 2 * 1024 * 1024;
    if ($file['size'] > $max_size) $errors[] = 'File too large (Max 2MB).';
    $allowed_extensions = ['pdf', 'docx', 'doc', 'txt'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if(!in_array($ext, $allowed_extensions)) $errors[] = 'Invalid file type.';

    if (empty($errors)) {
        $upload_dir = '../../uploads/';
        if (!is_dir($upload_dir)) @mkdir($upload_dir, 0755);
        if (!is_dir($upload_dir) || !is_writable($upload_dir)) {
            $errors[] = 'Upload directory error.';
        } else {
            $unique_filename = 'user_' . $user_id . '_' . time() . '.' . $ext;
            $target_path = $upload_dir . $unique_filename;
            if (move_uploaded_file($file['tmp_name'], $target_path)) {
                $uploaded_file_path = $target_path;
            } else {
                $errors[] = 'Failed to save file.';
            }
        }
    }
} elseif (isset($_FILES['optional_file']) && $_FILES['optional_file']['error'] !== UPLOAD_ERR_NO_FILE) {
    $errors[] = 'File upload error.';
}

if (empty($errors)) {
    $new_request_id = $_SESSION['next_request_id_alt']++;
    $_SESSION['requests_alt'][$new_request_id] = [
        'user_id' => $user_id,
        'book_id' => $book_id,
        'category_requested' => $category,
        'uploaded_file_path' => $uploaded_file_path,
        'request_status' => 'pending',
        'requested_at' => date('Y-m-d H:i:s'),
        'last_updated_at' => date('Y-m-d H:i:s')
    ];
    setFlashMessageAlt('status_message', 'Request submitted!', 'success');
    redirectAlt('../../index.php?action=dashboard');
} else {
    if ($uploaded_file_path && file_exists($uploaded_file_path)) @unlink($uploaded_file_path);
    setFlashMessageAlt('request_status', implode('<br>', $errors), 'error');
    redirectAlt('../../index.php?action=request_book_form');
}
?>