<?php
require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/functions.php';
require_once __DIR__ . '/../core/session.php';
require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/footer.php';

if (!isLoggedInAlt()) {
    redirectAlt('../../index.php?action=login_form');
}

renderHeaderAlt('Dashboard');
$user_id = $_SESSION['user_id_alt'];
?>
<h2>Dashboard</h2>
<p>Welcome, <?php echo htmlspecialchars($_SESSION['username_alt']); ?>!</p>
<h3>Your Book Requests</h3>
<?php
$user_requests = [];
foreach ($_SESSION['requests_alt'] as $req_id => $req) {
    if ($req['user_id'] == $user_id) {
        $book_info = $_SESSION['books_alt'][$req['book_id']] ?? ['title' => 'Unknown', 'author' => 'Unknown'];
        $user_requests[$req_id] = array_merge($req, $book_info);
    }
}
uasort($user_requests, function($a, $b) { return strtotime($b['requested_at']) <=> strtotime($a['requested_at']); });

if (empty($user_requests)): ?>
    <p>No requests yet. <a href="../../index.php?action=request_book_form">Request one?</a></p>
<?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Title</th>
                <th>Author</th>
                <th>Status</th>
                <th>Requested</th>
                <th>File</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($user_requests as $req_id => $req): ?>
                <tr>
                    <td><?php echo htmlspecialchars($req['title']); ?></td>
                    <td><?php echo htmlspecialchars($req['author']); ?></td>
                    <td><?php echo htmlspecialchars(ucfirst($req['request_status'])); ?></td>
                    <td><?php echo date('Y-m-d', strtotime($req['requested_at'])); ?></td>
                    <td><?php echo !empty($req['uploaded_file_path']) ? '<a href="'.htmlspecialchars($req['uploaded_file_path']).'" target="_blank">View</a>' : 'N/A'; ?></td>
                    <td>
                        <?php if ($req['request_status'] === 'pending'): ?>
                            <form action="../../index.php" method="POST" style="display:inline;">
                                <input type="hidden" name="action" value="cancel_request">
                                <input type="hidden" name="request_id" value="<?php echo $req_id; ?>">
                                <button type="submit" onclick="return confirm('Cancel request?');">Cancel</button>
                            </form>
                        <?php else: echo '-'; endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
<h3>Notifications</h3>
<?php
    $notified = false;
    foreach($user_requests as $req) {
         if ($req['request_status'] === 'completed' && isset($req['last_updated_at']) && strtotime($req['last_updated_at']) > strtotime('-1 day')) {
             echo '<p class="message success">Request for "'.htmlspecialchars($req['title']).'" completed.</p>';
             $notified = true;
         }
    }
    if (!$notified) echo "<p>No new notifications.</p>";
?>
<?php
renderFooterAlt();
?>