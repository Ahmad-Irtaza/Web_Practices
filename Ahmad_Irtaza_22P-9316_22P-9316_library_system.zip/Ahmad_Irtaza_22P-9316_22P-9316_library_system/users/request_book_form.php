<?php
require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/functions.php';
require_once __DIR__ . '/../core/session.php';
require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/footer.php';

if (!isLoggedInAlt()) {
    redirectAlt('../../index.php?action=login_form');
}

renderHeaderAlt('Request Book');
$user_id = $_SESSION['user_id_alt'];
$username = $_SESSION['username_alt'];
$user_email = $_SESSION['users_alt'][$user_id]['email'] ?? '';

$books_by_category = [];
$categories = ['app development', 'mobile development', 'AI'];
foreach ($_SESSION['books_alt'] as $book_id => $book) {
    $cat_lower = strtolower($book['category'] ?? '');
    if (in_array($cat_lower, $categories)) {
        $books_by_category[$cat_lower][$book_id] = $book;
    }
}
?>
<h2>Request a Book</h2>
<?php displayFlashMessageAlt('request_status'); displayFlashMessageAlt('form_error'); ?>
<form action="../../index.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="action" value="request_process">
    <div><label>Username:</label><input type="text" value="<?php echo htmlspecialchars($username); ?>" readonly></div>
    <div><label>Email:</label><input type="email" value="<?php echo htmlspecialchars($user_email); ?>" readonly></div>
    <div><label for="category">Category:</label><select id="category" name="category" required>
        <option value="">-- Select --</option>
        <?php foreach ($categories as $cat): if (!empty($books_by_category[strtolower($cat)])): ?>
            <option value="<?php echo htmlspecialchars($cat); ?>"><?php echo htmlspecialchars(ucwords($cat)); ?></option>
        <?php endif; endforeach; ?>
    </select></div>
    <div><label for="book_id">Book:</label><select id="book_id" name="book_id" required>
        <option value="">-- Select Category First --</option>
         <?php foreach ($books_by_category as $cat => $books_in_cat): ?>
            <optgroup label="<?php echo htmlspecialchars(ucwords($cat)); ?>" data-category="<?php echo htmlspecialchars($cat); ?>" style="display: none;">
                <?php foreach ($books_in_cat as $book_id_key => $book): ?>
                    <option value="<?php echo $book_id_key; ?>"><?php echo htmlspecialchars($book['title']) . ' - ' . htmlspecialchars($book['author']); ?></option>
                <?php endforeach; ?>
            </optgroup>
        <?php endforeach; ?>
    </select></div>
    <div><label for="optional_file">Optional File (PDF/DOCX/TXT, Max 2MB):</label><input type="file" id="optional_file" name="optional_file" accept=".pdf,.doc,.docx,.txt"></div>
    <div><button type="submit">Submit Request</button></div>
</form>
<script>
    document.getElementById('category').addEventListener('change', function() {
        const selectedCategory = this.value.toLowerCase();
        const bookSelect = document.getElementById('book_id');
        bookSelect.value = '';
        bookSelect.querySelectorAll('optgroup').forEach(og => og.style.display = 'none');
        if (selectedCategory) {
            const targetOptgroup = bookSelect.querySelector(`optgroup[data-category="${selectedCategory}"]`);
            if (targetOptgroup) targetOptgroup.style.display = 'block';
        }
        bookSelect.querySelector('option[value=""]').style.display = selectedCategory ? 'none' : 'block';
    });
</script>
<?php
renderFooterAlt();
?>